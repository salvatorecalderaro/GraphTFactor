import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import SAGEConv, global_mean_pool, global_max_pool


class GraphTFactor(nn.Module):
    """
    GraphTFactor model using GraphSAGE layers and an MLP classifier.
    """
    def __init__(self,in_channels,dropout=0.3):
        super().__init__()
        self.convs = nn.ModuleList([
            SAGEConv(in_channels, 256),
            SAGEConv(256, 128),
            SAGEConv(128, 64),
        ])

        self.bns = nn.ModuleList([
            nn.BatchNorm1d(256),
            nn.BatchNorm1d(128),
            nn.BatchNorm1d(64),
        ])

        # ===== MLP classifier =====
        self.mlp = nn.Sequential(
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(32, 1)
        )

        self.dropout = dropout

    def forward(self, data):
        """
        Forward pass of the GraphTFactor model.

        Parameters:
        - data (torch_geometric.data.Data): The input graph data.

        Returns:
        - torch.Tensor: The output logits of the model.
        """
        x, edge_index, batch = data.x, data.edge_index, data.batch
        for conv, bn in zip(self.convs, self.bns):
            x = conv(x, edge_index)
            x = bn(x)
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)

        x_max = global_max_pool(x, batch)
        x_mean = global_mean_pool(x, batch)
        
        x = torch.cat([x_max, x_mean], dim=1)  #
        return self.mlp(x).view(-1) 


def predict_graph(model,graph,device):
    """
    Predict the label of a graph using the trained GraphTFactor model.
    Parameters:
    - model (GraphTFactor): The trained GraphTFactor model.
    - graph (torch_geometric.data.Data): The input graph data.
    - device (torch.device): The device to run the prediction on.

    Returns:
    - int: The predicted label of the graph.
    - float: The predicted probability of the graph.
    """
    null_batch = torch.zeros(graph.num_nodes, dtype=torch.long, device=device)
    graph.batch = null_batch
    model.eval()
    with torch.no_grad():
        graph = graph.to(device)
        logits = model(graph)
        probs = torch.sigmoid(logits)
        preds = (probs >= 0.5).long()
    return preds.item(),probs.item()